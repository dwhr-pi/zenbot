node zenbot.js %*
