# Optimierte Konfigurationen für Bitcoin AI Strategie

Diese Datei enthält optimierte Konfigurationen für die Bitcoin AI Strategie, die für verschiedene Marktbedingungen getestet wurden.

## Verwendung der Konfigurationsdateien

Um eine Konfigurationsdatei zu verwenden, führen Sie folgenden Befehl aus:

```bash
./zenbot.sh trade --conf_file=/pfad/zu/config/default_config.json
```

Oder für Backtesting:

```bash
./zenbot.sh sim --conf_file=/pfad/zu/config/default_config.json --days=30
```

## Verfügbare Konfigurationen

1. **default_config.json** - Ausgewogene Standardkonfiguration für allgemeine Marktbedingungen
2. **optimized_config.json** - Optimierte Konfiguration basierend auf historischen Backtests

## Anpassung der Konfigurationen

Sie können die Konfigurationen nach Ihren Bedürfnissen anpassen. Die wichtigsten Parameter sind:

- **period**: Zeitintervall für die Analyse (z.B. 1h, 30m, 15m)
- **rsi_periods**, **oversold_rsi**, **overbought_rsi**: RSI-Parameter
- **stop_loss_pct**, **profit_target_pct**: Risikomanagement-Parameter

## Empfehlungen

- Testen Sie die Konfigurationen immer zuerst mit Backtesting und Paper Trading
- Passen Sie die Parameter an Ihre Risikotoleranz an
- Überprüfen Sie die Leistung regelmäßig und optimieren Sie bei Bedarf neu
