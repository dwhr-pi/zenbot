// Zenbot Konfigurationsdatei
// Generiert vom Zenbot Config Editor
// Weitere Informationen: https://github.com/DeviaVir/zenbot

var c = module.exports = {}

// Börse und Währungspaar
// Format: börse.WÄHRUNG1-WÄHRUNG2
c.selector = 'gdax.BTC-USD'

// Handelsstrategie
// Verfügbare Strategien: trend_ema, macd, rsi, bollinger, cci, srsi_macd, neural, momentum, sar, speed
c.strategy = 'trend_ema'

// Paper Trading (Simulation)
// true = Simulation ohne echtes Geld, false = Live-Handel
c.paper = true

// Kapital-Einstellungen
c.currency_capital = 1000
c.asset_capital = 0

// Trade-Einstellungen (in Prozent)
c.buy_pct = 99
c.sell_pct = 99
c.max_slippage_pct = 5

// Maximale Beträge (optional, leer lassen für unbegrenzt)
c.buy_max_amt = 0
c.sell_max_amt = 0

// Order-Einstellungen (in Millisekunden)
c.order_adjust_time = 5000
c.order_poll_time = 5000

// Markup/Markdown (in Prozent)
c.markup_pct = 0
c.markdown_buy_pct = 0
c.markdown_sell_pct = 0

// Backfill-Tage für historische Daten
c.days = 14

// Weitere Zenbot-Einstellungen können hier hinzugefügt werden
// Siehe Zenbot-Dokumentation für vollständige Optionen

