
#property indicator_separate_window
#property indicator_minimum -1.0
#property indicator_maximum 1.0
#property indicator_buffers 3
#property indicator_color1 Green
#property indicator_color2 Gray
#property indicator_color3 Black
#property indicator_level1 0.5
#property indicator_level2 -0.5

int gi_76 = 14;
extern int CountBars = 1000;
double g_ibuf_84[];
double g_ibuf_88[];
double g_ibuf_92[];
int gi_96;
int g_count_100;
int gi_104;
bool gi_108;
int g_ind_counted_112;
datetime g_time_116;
datetime g_time_120;
datetime g_time_124;
double gd_128;
double gd_136;
double gd_144;
double gd_152;
double gd_160;
double gd_168;
double gd_176;
double gd_184;
double gd_192;
double gd_200;
double gd_208;
double gd_216;
double gd_224;
double gd_232;
double gd_240;
double gd_248;
double gd_256;
double gd_264;
double gd_272;
double gd_280;
double gd_288;
double gd_296;
double gd_304;
double gd_320;
double gd_328;
double gd_336;
double gd_344;
double gd_352;
double gd_360;
double gd_368;
double gd_376;
double gd_384;
double gd_392;
double gd_400;
double gd_408;
double gd_416;
double gd_424;

int init() {

   SetIndexStyle(0, DRAW_HISTOGRAM, STYLE_SOLID);
   SetIndexStyle(1, DRAW_HISTOGRAM, STYLE_SOLID);
   SetIndexStyle(2, DRAW_HISTOGRAM, STYLE_SOLID);
   SetIndexBuffer(0, g_ibuf_84);
   SetIndexBuffer(1, g_ibuf_88);
   SetIndexBuffer(2, g_ibuf_92);
   IndicatorShortName("ProFx06(" + gi_76 + ")");
   SetIndexDrawBegin(0, Bars - CountBars);
   SetIndexDrawBegin(1, Bars - CountBars);
   SetIndexDrawBegin(2, Bars - CountBars);
   IndicatorDigits(MarketInfo(Symbol(), MODE_DIGITS));
   if (gi_76 - 1 >= 5) gi_104 = gi_76 - 1;
   else gi_104 = 5;
   gd_416 = 3 / (gi_76 + 2.0);
   gd_424 = 1.0 - gd_416;
   return (0);
}

int start() {

   g_ind_counted_112 = IndicatorCounted();
   if (g_ind_counted_112 < 0) return (-1);
   if (g_ind_counted_112 > gi_76) gi_96 = Bars - g_ind_counted_112 - 1;
   else gi_96 = Bars - gi_76 - 1;
   g_time_124 = Time[gi_96 + 1];
   if (g_time_124 != g_time_116 && gi_96 < Bars - gi_76 - 1) {
      if (g_time_124 == g_time_120) {
         gd_320 = gd_208;
         gd_328 = gd_216;
         gd_336 = gd_224;
         gd_344 = gd_232;
         gd_352 = gd_240;
         gd_360 = gd_248;
         gd_368 = gd_256;
         gd_376 = gd_264;
         gd_384 = gd_272;
         gd_392 = gd_280;
         gd_400 = gd_288;
         gd_408 = gd_296;
      } else return (-1);
   }
   if (gi_76 - 1 >= 5) gi_104 = gi_76 - 1;
   else gi_104 = 5;
   gd_416 = 3 / (gi_76 + 2.0);
   gd_424 = 1.0 - gd_416;
   while (gi_96 >= 0) {
      if (g_count_100 == 0) {
         g_count_100 = 1;
         gi_108 = FALSE;
      } else {
         if (g_count_100 >= gi_104) g_count_100 = gi_104 + 1;
         else g_count_100++;
         gd_136 = Close[gi_96] - (Close[gi_96 + 1]);
         gd_192 = MathAbs(gd_136);
         gd_320 = gd_424 * gd_320 + gd_416 * gd_136;
         gd_328 = gd_416 * gd_320 + gd_424 * gd_328;
         gd_176 = 1.5 * gd_320 - gd_328 / 2.0;
         gd_336 = gd_424 * gd_336 + gd_416 * gd_176;
         gd_344 = gd_416 * gd_336 + gd_424 * gd_344;
         gd_144 = 1.5 * gd_336 - gd_344 / 2.0;
         gd_352 = gd_424 * gd_352 + gd_416 * gd_144;
         gd_360 = gd_416 * gd_352 + gd_424 * gd_360;
         gd_152 = 1.5 * gd_352 - gd_360 / 2.0;
         gd_368 = gd_424 * gd_368 + gd_416 * gd_192;
         gd_376 = gd_416 * gd_368 + gd_424 * gd_376;
         gd_160 = 1.5 * gd_368 - gd_376 / 2.0;
         gd_384 = gd_424 * gd_384 + gd_416 * gd_160;
         gd_392 = gd_416 * gd_384 + gd_424 * gd_392;
         gd_184 = 1.5 * gd_384 - gd_392 / 2.0;
         gd_400 = gd_424 * gd_400 + gd_416 * gd_184;
         gd_408 = gd_416 * gd_400 + gd_424 * gd_408;
         gd_168 = 1.5 * gd_400 - gd_408 / 2.0;
         if (g_count_100 <= gi_104 && gd_136 != 0.0) gi_108 = TRUE;
         if (g_count_100 == gi_104 && gi_108 == FALSE) g_count_100 = 0;
      }
      if (g_count_100 > gi_104 && gd_168 > 0.0000000001) {
         gd_128 = 50.0 * (gd_152 / gd_168 + 1.0);
         if (gd_128 > 100.0) gd_128 = 100.0;
         if (gd_128 < 0.0) gd_128 = 0.0;
      } else gd_128 = 50.0;
      gd_304 = gd_128 / 50.0 - 1.0;
      if (gi_96 == 1) {
         g_time_120 = Time[1];
         g_time_116 = Time[0];
         gd_208 = gd_320;
         gd_216 = gd_328;
         gd_224 = gd_336;
         gd_232 = gd_344;
         gd_240 = gd_352;
         gd_248 = gd_360;
         gd_256 = gd_368;
         gd_264 = gd_376;
         gd_272 = gd_384;
         gd_280 = gd_392;
         gd_288 = gd_400;
         gd_296 = gd_408;
      }
      gd_200 = gd_304 - (g_ibuf_84[gi_96 + 1]) - (g_ibuf_88[gi_96 + 1]) - (g_ibuf_92[gi_96 + 1]);
      g_ibuf_84[gi_96] = 0.0;
      g_ibuf_88[gi_96] = 0.0;
      g_ibuf_92[gi_96] = 0.0;
      if (gd_200 > 0.0) g_ibuf_84[gi_96] = gd_304;
      else {
         if (gd_200 < 0.0) g_ibuf_88[gi_96] = gd_304;
         else g_ibuf_92[gi_96] = gd_304;
      }
      gi_96--;
   }
   return (0);
}

int deinit() {

   return (0);
}