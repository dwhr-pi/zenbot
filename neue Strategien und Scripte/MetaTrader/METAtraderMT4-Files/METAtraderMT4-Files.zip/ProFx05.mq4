
#property indicator_separate_window
#property indicator_minimum 0.0
#property indicator_maximum 100.0
#property indicator_buffers 1
#property indicator_color1 LawnGreen
#property indicator_level3 50.0


int gi_76 = 16;
double g_ibuf_80[];

int init() {

   SetIndexStyle(0, DRAW_LINE, STYLE_SOLID, 3);
   SetIndexBuffer(0, g_ibuf_80);
   IndicatorShortName("ProFx05");
   return (0);
}

int deinit() {

   return (0);
}

int start() {
   double ld_4;
   double ld_12;
   double ld_20;
   double ld_28;
   double ld_36;
   double ld_44;
   double ld_52;
   double ld_60;
   double ld_68;
   double ld_76;
   double ld_84;
   double ld_92;
   double ld_100;
   double ld_108;
   double ld_116;
   double ld_124;
   double ld_132;
   double ld_140;
   double ld_148;
   double ld_156;
   double ld_164;
   double ld_172;
   double ld_180;
   double ld_188;
   double ld_196;
   double ld_204;
   double ld_212;

   double ld_220 = Bars - gi_76 - 1;
   for (int li_228 = ld_220; li_228 >= 0; li_228--) {
      if (ld_12 == 0.0) {
         ld_12 = 1.0;
         ld_20 = 0.0;
         if (gi_76 - 1 >= 5) ld_4 = gi_76 - 1.0;
         else ld_4 = 5.0;
         ld_84 = 100.0 * ((High[li_228] + Low[li_228] + Close[li_228]) / 3.0);
         ld_100 = 3.0 / (gi_76 + 2.0);
         ld_108 = 1.0 - ld_100;
      } else {
         if (ld_4 <= ld_12) ld_12 = ld_4 + 1.0;
         else ld_12 += 1.0;
         ld_92 = ld_84;
         ld_84 = 100.0 * ((High[li_228] + Low[li_228] + Close[li_228]) / 3.0);
         ld_36 = ld_84 - ld_92;
         ld_116 = ld_108 * ld_116 + ld_100 * ld_36;
         ld_124 = ld_100 * ld_116 + ld_108 * ld_124;
         ld_44 = 1.5 * ld_116 - ld_124 / 2.0;
         ld_132 = ld_108 * ld_132 + ld_100 * ld_44;
         ld_212 = ld_100 * ld_132 + ld_108 * ld_212;
         ld_52 = 1.5 * ld_132 - ld_212 / 2.0;
         ld_140 = ld_108 * ld_140 + ld_100 * ld_52;
         ld_156 = ld_100 * ld_140 + ld_108 * ld_156;
         ld_60 = 1.5 * ld_140 - ld_156 / 2.0;
         ld_164 = ld_108 * ld_164 + ld_100 * MathAbs(ld_36);
         ld_172 = ld_100 * ld_164 + ld_108 * ld_172;
         ld_68 = 1.5 * ld_164 - ld_172 / 2.0;
         ld_180 = ld_108 * ld_180 + ld_100 * ld_68;
         ld_188 = ld_100 * ld_180 + ld_108 * ld_188;
         ld_148 = 1.5 * ld_180 - ld_188 / 2.0;
         ld_196 = ld_108 * ld_196 + ld_100 * ld_148;
         ld_204 = ld_100 * ld_196 + ld_108 * ld_204;
         ld_76 = 1.5 * ld_196 - ld_204 / 2.0;
         if (ld_4 >= ld_12 && ld_84 != ld_92) ld_20 = 1.0;
         if (ld_4 == ld_12 && ld_20 == 0.0) ld_12 = 0.0;
      }
      if (ld_4 < ld_12 && ld_76 > 0.0000000001) {
         ld_28 = 50.0 * (ld_60 / ld_76 + 1.0);
         if (ld_28 > 100.0) ld_28 = 100.0;
         if (ld_28 < 0.0) ld_28 = 0.0;
      } else ld_28 = 50.0;
      g_ibuf_80[li_228] = ld_28;
   }
   return (0);
}