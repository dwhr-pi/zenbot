//+------------------------------------------------------------------+
//|                                              CloseAfterXpips.mq4 |
//|                        closes trades after x pips profit or loss |
//+------------------------------------------------------------------+
#property copyright "Copyright � 2014 fxdaytrader, http://ForexBaron.net"
#property link      "http://ForexBaron.net"

extern double CloseAfterXpips          = 50;
extern bool   CloseInProfit            = true;
extern bool   CloseInLoss              = true;
extern int    MagicNumber              = 0;//0:manual trades
extern bool   FilterByMagicNumber      = false;
extern bool   FilterBySymbol           = false;
extern bool   PrintToJournal           = true;
extern bool   SendTestTradesOnBacktest = false;//false;//should send one long and one short trade when backtester starts
int buys,sells,Multiplier;
double pips2dbl;

int init()  {
 CloseAfterXpips = MathAbs(CloseAfterXpips);
 if (SendTestTradesOnBacktest && IsTesting()) {
  RefreshRates();
  OrderSend(Symbol(),OP_BUY,0.1,Ask,50,0,0,"TestTrade buy",MagicNumber,0,CLR_NONE);
  OrderSend(Symbol(),OP_SELL,0.1,Bid,50,0,0,"TestTrade sell",MagicNumber,0,CLR_NONE);
 }
 return(0);
}

int deinit() {
 Comment("");
 return(0);
}

int start() {
   if (CloseAfterXpips!=0.00) {
   CountOpenTrades(Symbol(),MagicNumber);
    Comment("CloseAfterXpips EA, � 2014 fxdaytrader, http://ForexBaron.net"+"\n\n"+
         " CloseAfterXpips="+DoubleToStr(CloseAfterXpips,2)+", CloseInProfit="+bool2txt(CloseInProfit)+", CloseInLoss="+bool2txt(CloseInLoss)+"\n"+
         " FilterByMagicNumber="+bool2txt(FilterByMagicNumber)+", MagicNumber="+MagicNumber+", FilterBySymbol="+bool2txt(FilterBySymbol)+"\n"+
         " current open trades -> "+(buys+sells)+" (buys: "+buys+", sells: "+sells+")");
    if ((buys+sells)>0) CheckForCloseTradesAfterXpips(Symbol(),MagicNumber);
   }
   else if (CloseAfterXpips==0.00) {
    Comment("CloseAfterXpips EA, � 2014 fxdaytrader, http://ForexBaron.net"+"\n\n"+
            " ******* ERROR: CloseAfterXpips must be > 0 *******");
   }

 return(0);
}

void CountOpenTrades(string symbol,int magicnumber) {
 buys=0;
 sells=0;
 for (int cnt=OrdersTotal()-1; cnt>=0; cnt--) {
  if (!OrderSelect(cnt,SELECT_BY_POS,MODE_TRADES)) continue;
  if (FilterBySymbol && OrderSymbol()!=symbol) continue;
  if (FilterByMagicNumber && OrderMagicNumber()!=magicnumber) continue;
   {
     if (OrderType()==OP_BUY) buys++;
     if (OrderType()==OP_SELL) sells++;
    }
  }
}

string bool2txt(int lbool) {
 if (lbool==true) return("yes");
 if (lbool==false) return("no");
 return("unknown");
}

void BrokerDigitAdjust(string symbol) {
 Multiplier=1;
 if (MarketInfo(symbol,MODE_DIGITS)==3 || MarketInfo(symbol,MODE_DIGITS)==5) Multiplier=10;
 if (MarketInfo(symbol,MODE_DIGITS)==6) Multiplier=100;
 if (MarketInfo(symbol,MODE_DIGITS)==7) Multiplier=1000;
 pips2dbl=Multiplier*MarketInfo(symbol,MODE_POINT);
}

void CheckForCloseTradesAfterXpips(string symbol,int magicnumber) {
 bool result;
 double profitpips=0;
 for (int cnt=OrdersTotal()-1; cnt>=0; cnt--) {
  if (!OrderSelect(cnt,SELECT_BY_POS,MODE_TRADES)) continue;
  if (FilterBySymbol && OrderSymbol()!=symbol) continue;
  if (FilterByMagicNumber && OrderMagicNumber()!=magicnumber) continue;
   {
     RefreshRates();
     BrokerDigitAdjust(OrderSymbol());
    double ask = MarketInfo(OrderSymbol(),MODE_ASK);
    double bid = MarketInfo(OrderSymbol(),MODE_BID);
     if (OrderType()==OP_BUY)  {
      profitpips = (bid - OrderOpenPrice())/pips2dbl;
      if ((profitpips>=CloseAfterXpips && CloseInProfit)||(profitpips<=-1*CloseAfterXpips && CloseInLoss)) result = OrderClose(OrderTicket(),OrderLots(),bid,99999,CLR_NONE);
      if (PrintToJournal) {
       if (profitpips>=CloseAfterXpips && CloseInProfit) Print("CloseAfterXpips EA: Closed BUY ORDER ticket="+OrderTicket()+" in profit after "+DoubleToStr(CloseAfterXpips,2)+" pips (profit: "+DoubleToStr(OrderProfit()+OrderCommission()+OrderSwap(),2)+" "+AccountCurrency()+")");
       if (profitpips<=-1*CloseAfterXpips && CloseInLoss) Print("CloseAfterXpips EA: Closed BUY ORDER ticket="+OrderTicket()+" in loss after "+DoubleToStr(CloseAfterXpips,2)+" pips (profit: "+DoubleToStr(OrderProfit()+OrderCommission()+OrderSwap(),2)+" "+AccountCurrency()+")");
      }
     }
     if (OrderType()==OP_SELL) {
      profitpips = (OrderOpenPrice() - ask)/pips2dbl;
      if ((profitpips>=CloseAfterXpips && CloseInProfit)||(profitpips<=-1*CloseAfterXpips && CloseInLoss)) result = OrderClose(OrderTicket(),OrderLots(),ask,99999,CLR_NONE);
      if (PrintToJournal) {
       if (profitpips>=CloseAfterXpips && CloseInProfit) Print("CloseAfterXpips EA: Closed SELL ORDER ticket="+OrderTicket()+" in profit after "+DoubleToStr(CloseAfterXpips,2)+" pips (profit: "+DoubleToStr(OrderProfit()+OrderCommission()+OrderSwap(),2)+" "+AccountCurrency()+")");
       if (profitpips<=-1*CloseAfterXpips && CloseInLoss) Print("CloseAfterXpips EA: Closed SELL ORDER ticket="+OrderTicket()+" in loss after "+DoubleToStr(CloseAfterXpips,2)+" pips (profit: "+DoubleToStr(OrderProfit()+OrderCommission()+OrderSwap(),2)+" "+AccountCurrency()+")");
      }
     }
    }
  }
}