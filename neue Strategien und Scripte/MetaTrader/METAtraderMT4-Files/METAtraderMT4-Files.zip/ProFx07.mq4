
#property indicator_separate_window
#property indicator_minimum 0.0
#property indicator_maximum 1.0
#property indicator_buffers 4
#property indicator_color1 Gray
#property indicator_color2 Green
#property indicator_color3 Black
#property indicator_color4 Black



extern int Minutes = 30;
double g_ibuf_80[];
double g_ibuf_84[];
double g_ibuf_88[];
double g_ibuf_92[];
double g_isar_120;
double g_iadx_128;
double g_iadx_136;
string gs_144;

int init() {

   SetIndexStyle(0, DRAW_HISTOGRAM, STYLE_SOLID, 3);
   SetIndexBuffer(0, g_ibuf_80);
   SetIndexStyle(1, DRAW_HISTOGRAM, STYLE_SOLID, 3);
   SetIndexBuffer(1, g_ibuf_84);
   SetIndexStyle(2, DRAW_HISTOGRAM, STYLE_SOLID, 2);
   SetIndexBuffer(2, g_ibuf_88);
   SetIndexStyle(3, DRAW_HISTOGRAM, STYLE_SOLID, 2);
   SetIndexBuffer(3, g_ibuf_92);
   switch (Minutes) {
   case 1:
      gs_144 = "Period_M1";
      break;
   case 5:
      gs_144 = "Period_M5";
      break;
   case 15:
      gs_144 = "Period_M15";
      break;
   case 30:
      gs_144 = "Period_M30";
      break;
   case 60:
      gs_144 = "Period_H1";
      break;
   case 240:
      gs_144 = "Period_H4";
      break;
   case 1440:
      gs_144 = "Period_D1";
      break;
   case 10080:
      gs_144 = "Period_W1";
      break;
   case 43200:
      gs_144 = "Period_MN1";
      break;
   default:
      gs_144 = "Current Timeframe";
      Minutes = 0;
   }
   IndicatorShortName("ProFx07(" + gs_144 + ")");
   return (0);
}

int deinit() {

   return (0);
}

int start() {

   int l_ind_counted_4 = IndicatorCounted();
   for (int li_8 = 0; li_8 < 7000; li_8++) {
      g_ibuf_80[li_8] = 0;
      g_ibuf_84[li_8] = 0;
      g_ibuf_88[li_8] = 0;
      g_ibuf_92[li_8] = 0;
      g_iadx_128 = iADX(NULL, Minutes, 14, PRICE_CLOSE, MODE_PLUSDI, li_8);
      g_iadx_136 = iADX(NULL, Minutes, 14, PRICE_CLOSE, MODE_MINUSDI, li_8);
      g_isar_120 = iSAR(NULL, Minutes, 0.02, 0.2, li_8);
      if (g_isar_120 < iClose(NULL, Minutes, li_8) && g_iadx_128 > g_iadx_136) g_ibuf_84[li_8] = 1;
      if (g_isar_120 < iClose(NULL, Minutes, li_8) && g_iadx_136 > g_iadx_128) g_ibuf_92[li_8] = 1;
      if (g_isar_120 > iClose(NULL, Minutes, li_8) && g_iadx_136 > g_iadx_128) g_ibuf_80[li_8] = 1;
      if (g_isar_120 > iClose(NULL, Minutes, li_8) && g_iadx_128 > g_iadx_136) g_ibuf_88[li_8] = 1;
      if (g_ibuf_80[li_8] == 0.0 && g_ibuf_84[li_8] == 0.0) {
      }
   }
   return (0);
}