//+------------------------------------------------------------------+
//|                                              Coba Multi Pair.mq4 |
//|                                    Copyright 2022, JIMBARWANA FX |
//|                                        https://t.me/JIMBARWANAFX |
//+------------------------------------------------------------------+
#property copyright "Copyright 2022, JIMBARWANA FX"
#property link      "https://t.me/JIMBARWANAFX"
#property version   "1.00"
#property strict


input  double  Lots       = 0.01;
input  int     MagicID    = 1111;

string EAName    = "EA Comment";

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
   if(CountTrades_0(OP_BUY)==0) {
      if(OrderSend(Symbol(),OP_BUY,Lots,Ask,10,0,0,EAName,MagicID,0,clrBlue)<=0)
      Print("Order Send Buy Error. Lot : ", Lots, " - SL : ", 0, " - TP : ", 0, ". Error Code : ", GetLastError()); 
     }
   
   if(CountTrades_0(OP_SELL)==0) {
      if(OrderSend(Symbol(),OP_SELL,Lots,Bid,10,0,0,EAName,MagicID,0,clrRed)<=0)
      Print("Order Send Sell Error. Lot : ", Lots, " - SL : ", 0, " - TP : ", 0, ". Error Code : ", GetLastError()); 
     }
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
int CountTrades_0(int tipe)
  {
   int count=0;
   int trade=0;
   for(trade=OrdersTotal()-1;trade>=0;trade--)
     {
      if(OrderSelect(trade,SELECT_BY_POS,MODE_TRADES))
      if(OrderSymbol()==Symbol() || OrderMagicNumber()==MagicID)
      if(OrderType()==tipe)
         count++;
     }
   return(count);
  }   
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+

