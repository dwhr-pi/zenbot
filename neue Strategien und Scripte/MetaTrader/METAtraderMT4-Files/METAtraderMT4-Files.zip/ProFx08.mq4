
#property indicator_chart_window



extern int NumberOfDays = 10;
extern string Begin_1 = "06:30";
extern string End_1 = "15:00";
extern color Color_1 = Gray;
extern string Begin_2 = "13:00";
extern string End_2 = "21:00";
extern color Color_2 = Gray;
bool gi_120 = FALSE;

void init() {

   DeleteObjects();
   for (int l_count_0 = 0; l_count_0 < NumberOfDays; l_count_0++) {
      CreateObjects("PWT1" + l_count_0, Color_1);
      CreateObjects("PWT2" + l_count_0, Color_2);
   }
   Comment("");
}

void deinit() {

   DeleteObjects();
   Comment("");
}

void CreateObjects(string a_name_0, color a_color_8) {
   ObjectCreate(a_name_0, OBJ_RECTANGLE, 0, 0, 0, 0, 0);
   ObjectSet(a_name_0, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSet(a_name_0, OBJPROP_COLOR, a_color_8);
   ObjectSet(a_name_0, OBJPROP_BACK, TRUE);
}

void DeleteObjects() {
   for (int l_count_0 = 0; l_count_0 < NumberOfDays; l_count_0++) {
      ObjectDelete("PWT1" + l_count_0);
      ObjectDelete("PWT2" + l_count_0);
   }
}

void start() {
   int l_datetime_4;

   int li_0 = 0;
   if (li_0 == 0) {
      l_datetime_4 = TimeCurrent();
      for (int l_count_8 = 0; l_count_8 < NumberOfDays; l_count_8++) {
         DrawObjects(l_datetime_4, "PWT1" + l_count_8, Begin_1, End_1);
         DrawObjects(l_datetime_4, "PWT2" + l_count_8, Begin_2, End_2);
         for (l_datetime_4 = decDateTradeDay(l_datetime_4); TimeDayOfWeek(l_datetime_4) > 5; l_datetime_4 = decDateTradeDay(l_datetime_4)) {
         }
      }
   }
}

void DrawObjects(int ai_0, string a_name_4, string as_12, string as_20) {
   int l_str2time_28 = StrToTime(TimeToStr(ai_0, TIME_DATE) + " " + as_12);
   int l_str2time_32 = StrToTime(TimeToStr(ai_0, TIME_DATE) + " " + as_20);
   int l_shift_52 = iBarShift(NULL, 0, l_str2time_28);
   int l_shift_56 = iBarShift(NULL, 0, l_str2time_32);
   double l_high_36 = High[iHighest(NULL, 0, MODE_HIGH, l_shift_52 - l_shift_56, l_shift_56)];
   double ld_44 = Low[iLowest(NULL, 0, MODE_LOW, l_shift_52 - l_shift_56, l_shift_56)];
   if (!gi_120) {
      l_high_36 = 0;
      ld_44 = 2.0 * ld_44;
   }
   ObjectSet(a_name_4, OBJPROP_TIME1, l_str2time_28);
   ObjectSet(a_name_4, OBJPROP_PRICE1, l_high_36);
   ObjectSet(a_name_4, OBJPROP_TIME2, l_str2time_32);
   ObjectSet(a_name_4, OBJPROP_PRICE2, ld_44);
}

int decDateTradeDay(int ai_0) {
   int li_4 = TimeYear(ai_0);
   int li_8 = TimeMonth(ai_0);
   int li_12 = TimeDay(ai_0);
   int l_hour_16 = TimeHour(ai_0);
   int l_minute_20 = TimeMinute(ai_0);
   li_12--;
   if (li_12 == 0) {
      li_8--;
      if (li_8 == 0) {
         li_4--;
         li_8 = 12;
      }
      if (li_8 == 1 || li_8 == 3 || li_8 == 5 || li_8 == 7 || li_8 == 8 || li_8 == 10 || li_8 == 12) li_12 = 31;
      if (li_8 == 2) {
         if (MathMod(li_4, 4) == 0.0) li_12 = 29;
         else li_12 = 28;
      }
      if (li_8 == 4 || li_8 == 6 || li_8 == 9 || li_8 == 11) li_12 = 30;
   }
   return (StrToTime(li_4 + "." + li_8 + "." + li_12 + " " + l_hour_16 + ":" + l_minute_20));
}