module.exports = {
  // Zenbot configuration for User B (PM2 Solution)
  selector: 'kraken.ETH-EUR',
  asset: 'ETH',
  currency: 'EUR',
  exchange: 'kraken',
  kraken: {
    key: 'YOUR_KRAKEN_API_KEY_B',
    secret: 'YOUR_KRAKEN_SECRET_B',
  },
  strategy: {
    name: 'macd',
    period: '30m',
    min_periods: 52,
    markup_pct: 0.3,
    order_type: 'maker',
    sell_rate_limit: 0.002,
    buy_rate_limit: 0.002,
  },
  paper: {
    enabled: true,
    maker_fee_pct: 0.15,
    taker_fee_pct: 0.15,
    slippage: 0.05,
    starting_balance: 2000,
    currency_capital: 2000,
    asset_capital: 0,
  },
  web: {
    port: 8082, // Unique port for User B's web UI
  },
};

