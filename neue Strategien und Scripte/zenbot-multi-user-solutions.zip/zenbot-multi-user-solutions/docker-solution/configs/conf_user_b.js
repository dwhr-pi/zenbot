module.exports = {
  // Zenbot configuration for User B
  // Replace with actual API keys and settings
  selector: 'kraken.ETH-EUR',
  asset: 'ETH',
  currency: 'EUR',
  exchange: 'kraken',
  // ... other settings
  // Example API keys (replace with your own)
  kraken: {
    key: 'YOUR_KRAKEN_API_KEY_B',
    secret: 'YOUR_KRAKEN_SECRET_B',
  },
  // Strategy settings
  strategy: {
    name: 'macd',
    period: '30m',
    min_periods: 52,
    markup_pct: 0.3,
    order_type: 'maker',
    sell_rate_limit: 0.002,
    buy_rate_limit: 0.002,
    // ... other strategy settings
  },
  // Paper trading settings
  paper: {
    enabled: true,
    maker_fee_pct: 0.15,
    taker_fee_pct: 0.15,
    slippage: 0.05,
    starting_balance: 2000,
    currency_capital: 2000,
    asset_capital: 0,
  },
};

