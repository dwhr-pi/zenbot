module.exports = {
  // Zenbot configuration for User A
  // Replace with actual API keys and settings
  selector: 'binance.BTC-USDT',
  asset: 'BTC',
  currency: 'USDT',
  exchange: 'binance',
  // ... other settings
  // Example API keys (replace with your own)
  binance: {
    key: 'YOUR_BINANCE_API_KEY_A',
    secret: 'YOUR_BINANCE_SECRET_A',
  },
  // Strategy settings
  strategy: {
    name: 'trend_ema',
    period: '1h',
    min_periods: 52,
    markup_pct: 0.2,
    order_type: 'maker',
    sell_rate_limit: 0.001,
    buy_rate_limit: 0.001,
    // ... other strategy settings
  },
  // Paper trading settings
  paper: {
    enabled: true,
    maker_fee_pct: 0.1,
    taker_fee_pct: 0.1,
    slippage: 0.05,
    starting_balance: 1000,
    currency_capital: 1000,
    asset_capital: 0,
  },
};


