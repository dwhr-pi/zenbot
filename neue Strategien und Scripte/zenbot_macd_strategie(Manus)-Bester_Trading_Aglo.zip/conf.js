# Zenbot Konfigurationsdatei für optimierte MACD-Strategie

// Diese Konfigurationsdatei enthält optimierte Einstellungen für die MACD-Strategie in Zenbot
// Speichern Sie diese Datei als conf.js im Hauptverzeichnis von Zenbot

var c = module.exports = {}

// Verbindung zur Datenbank
c.mongo = {
  host: process.env.MONGODB_PORT_27017_TCP_ADDR || 'localhost',
  port: 27017,
  db: 'zenbot4'
}

// Handelsparameter
c.trade = {
  enabled: false,           // Auf true setzen, um Live-Trading zu aktivieren
  paper: true,              // Paper-Trading-Modus (kein echtes Geld)
  currency_capital: 1000,   // Startkapital in der Basiswährung
  asset_capital: 0,         // Startkapital in der Handelswährung
  order_type: 'maker',      // Auftragstyp: 'maker' (Limit) oder 'taker' (Market)
  markup_pct: 0.5,          // Markup für Verkaufsaufträge in Prozent
  markdown_pct: 0.5,        // Markdown für Kaufaufträge in Prozent
  sell_stop_pct: 2.0,       // Stop-Loss für Verkäufe in Prozent
  buy_stop_pct: 1.5,        // Stop-Loss für Käufe in Prozent
  profit_stop_enable_pct: 1.5, // Aktivierungsschwelle für Gewinnmitnahme
  profit_stop_pct: 5.0,     // Prozentsatz für Gewinnmitnahme
  max_slippage_pct: 5,      // Maximaler Slippage-Prozentsatz
  max_sell_loss_pct: 25,    // Maximaler Verlust bei Verkäufen in Prozent
  max_buy_loss_pct: 25,     // Maximaler Verlust bei Käufen in Prozent
  order_adjust_time: 5000,  // Zeit in ms, um Aufträge anzupassen
  order_poll_time: 5000,    // Zeit in ms, um Aufträge zu überprüfen
  sell_cancel_time: 60000,  // Zeit in ms, um Verkaufsaufträge abzubrechen
  buy_cancel_time: 30000,   // Zeit in ms, um Kaufaufträge abzubrechen
  min_order_size: 0.01,     // Minimale Auftragsgröße
  keep_lookback_periods: 50, // Anzahl der zu speichernden Lookback-Perioden
  exact_buy_orders: false,  // Exakte Kaufaufträge
  exact_sell_orders: false, // Exakte Verkaufsaufträge
  disable_options: false,   // Optionen deaktivieren
  quarentine_time: 3600000, // Quarantänezeit in ms
  rsi_periods: 25           // RSI-Perioden
}

// MACD-Strategie-Konfiguration
c.macd = {
  period: '1h',             // Zeitperiode für jeden Handelszyklus
  min_periods: 52,          // Minimale Anzahl an historischen Perioden
  ema_short_period: 10,     // Anzahl der Perioden für die kürzere EMA
  ema_long_period: 26,      // Anzahl der Perioden für die längere EMA
  signal_period: 9,         // Anzahl der Perioden für die Signal-EMA
  up_trend_threshold: 0.05, // Schwellenwert für Kaufsignale
  down_trend_threshold: 0.05, // Schwellenwert für Verkaufssignale
  overbought_rsi_periods: 25, // Anzahl der Perioden für den überkauften RSI
  overbought_rsi: 70        // Verkaufen, wenn RSI diesen Wert überschreitet
}

// Börsen-Konfiguration (Beispiel für Binance)
c.binance = {
  enabled: true,
  key: '',                  // Hier Ihren API-Key eintragen
  secret: '',               // Hier Ihren API-Secret eintragen
  normalized_pair: 'BTC/USDT' // Handelspaar
}

// Weitere Börsen können hier konfiguriert werden
// c.coinbase_pro = { ... }
// c.kraken = { ... }

// Benachrichtigungen (optional)
c.notifiers = {}

// Telegram-Benachrichtigungen (optional)
c.notifiers.telegram = {
  enabled: false,
  token: '',                // Telegram Bot Token
  chat_id: ''               // Telegram Chat ID
}

// Weitere Konfigurationsoptionen
c.backtester = {
  save_report: true         // Backtesting-Bericht speichern
}

// Logging-Konfiguration
c.debug = false             // Debug-Modus aktivieren/deaktivieren
c.debug_trader = false      // Trader-Debug aktivieren/deaktivieren
c.debug_orders = false      // Auftrags-Debug aktivieren/deaktivieren
